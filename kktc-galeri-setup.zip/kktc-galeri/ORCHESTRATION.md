# 🧠 KKTC Araç Galerisi — Orkestrasyon & Checkpoint

> **Son Güncelleme:** `___`
> **Mevcut Faz:** ⬜ Başlatılmadı
> **Detaylı Spec:** `SPEC.md`

---

## Görev Takip Tablosu

| # | Görev | Agent | Durum | Faz | Bağımlılık |
|---|-------|-------|-------|-----|------------|
| T-001 | Monorepo: pnpm workspace, root package.json, tsconfig | @coder-light | ⬜ | 1 | — |
| T-002 | apps/api: Express + TS + nodemon setup | @coder-light | ⬜ | 1 | T-001 |
| T-003 | apps/web: Next.js 14 + TS + Tailwind + shadcn/ui init | @coder-light | ⬜ | 1 | T-001 |
| T-004 | packages/shared: Paylaşılan tipler (enums, interfaces) | @coder-light | ⬜ | 1 | T-001 |
| T-005 | Docker Compose: PostgreSQL 15 + Redis 7 + .env | @coder-light | ⬜ | 1 | T-001 |
| T-006 | Prisma schema: TÜM modeller (SPEC.md referans) | @coder-heavy | ⬜ | 1 | T-002,T-005 |
| T-007 | Prisma seed: Vergiler, ülkeler, döviz, örnek galeri/admin | @coder-light | ⬜ | 1 | T-006 |
| T-008 | JWT Auth: register/login/refresh/me + bcrypt | @coder-heavy | ⬜ | 1 | T-006 |
| T-009 | Middleware: auth, role (6 rol), gallery tenant | @coder-heavy | ⬜ | 1 | T-008 |
| T-010 | Error handling middleware + Zod validator | @coder-light | ⬜ | 1 | T-002 |
| T-011 | Frontend: Sidebar layout (master+galeri ayrı), header | @coder-light | ⬜ | 1 | T-003 |
| T-012 | Frontend: Auth sayfaları (login/register) + authStore | @coder-heavy | ⬜ | 1 | T-008,T-011 |
| T-013 | Auth testleri | @tester | ⬜ | 1 | T-008,T-009 |
| T-014 | Proje ağacı oluştur | @tree-mapper | ⬜ | 1 | T-011 |
| — | **SUPERVISOR ONAY — FAZ 1** | Supervisor | ⬜ | 1 | T-013 |
| T-015 | M1: TaxRate CRUD API + TaxRateHistory + AuditLog | @coder-heavy | ⬜ | 2 | T-009 |
| T-016 | M1: TaxRate UI (tablo, düzenleme modalı, geçmiş) | @coder-heavy | ⬜ | 2 | T-015 |
| T-017 | M3: OriginCountry CRUD API | @coder-light | ⬜ | 2 | T-009 |
| T-018 | M3: OriginCountry UI (tablo, modal) | @coder-light | ⬜ | 2 | T-017 |
| T-019 | M2: ExchangeRate CRUD API + cron job + API fetch | @coder-heavy | ⬜ | 2 | T-009 |
| T-020 | M2: ExchangeRate UI + settings + geçmiş grafiği | @coder-heavy | ⬜ | 2 | T-019 |
| T-021 | M4: Gallery CRUD API | @coder-light | ⬜ | 2 | T-009 |
| T-022 | M4: Gallery UI (liste, detay, abonelik) | @coder-light | ⬜ | 2 | T-021 |
| T-023 | M5: Notification API (send, read tracking) | @coder-heavy | ⬜ | 2 | T-021 |
| T-024 | M5: Notification UI (oluştur, liste, okunma) | @coder-light | ⬜ | 2 | T-023 |
| T-025 | M6: AuditLog API + UI (liste, filtreleme, detay) | @coder-heavy | ⬜ | 2 | T-009 |
| T-026 | Master Dashboard sayfası (istatistik kartları) | @coder-light | ⬜ | 2 | T-015,T-021 |
| T-027 | Master panel testleri | @tester | ⬜ | 2 | T-025 |
| — | **SUPERVISOR ONAY — FAZ 2** | Supervisor | ⬜ | 2 | T-027 |
| T-028 | G1: Vehicle CRUD API (tüm ilişkiler, filtreleme, pagination) | @coder-heavy | ⬜ | 3 | T-009 |
| T-029 | G1.2: Vehicle listesi UI (grid + liste + tab'lar) | @coder-heavy | ⬜ | 3 | T-028 |
| T-030 | G1: Vehicle ekleme formu (multi-step) | @coder-heavy | ⬜ | 3 | T-028 |
| T-031 | G1.3: Vehicle detay sayfası | @coder-heavy | ⬜ | 3 | T-028 |
| T-032 | G1.1: Transit listesi + stoğa geçiş | @coder-light | ⬜ | 3 | T-028 |
| T-033 | VehicleImage: Cloudinary upload entegrasyonu | @coder-heavy | ⬜ | 3 | T-028 |
| T-034 | G1.4: VehicleDocument yükleme/yönetim | @coder-light | ⬜ | 3 | T-028 |
| T-035 | VehicleExpense: Ek gider CRUD | @coder-light | ⬜ | 3 | T-028 |
| T-036 | Araç modülü testleri | @tester | ⬜ | 3 | T-033 |
| — | **SUPERVISOR ONAY — FAZ 3** | Supervisor | ⬜ | 3 | T-036 |
| T-037 | G2.1: Calculator service (TAM vergi motoru) | @coder-heavy | ⬜ | 4 | T-015,T-017,T-019 |
| T-038 | TaxSnapshot mekanizması | @coder-heavy | ⬜ | 4 | T-037 |
| T-039 | Calculator API endpoint'leri | @coder-heavy | ⬜ | 4 | T-037,T-038 |
| T-040 | G2.2: Calculator UI (form + sonuç ekranı) | @coder-heavy | ⬜ | 4 | T-039 |
| T-041 | Calculator PDF rapor oluşturma | @coder-heavy | ⬜ | 4 | T-039 |
| T-042 | Calculator → Araca kaydetme entegrasyonu | @coder-light | ⬜ | 4 | T-039,T-028 |
| T-043 | Calculator testleri (6+ senaryo — KRİTİK) | @tester | ⬜ | 4 | T-037 |
| — | **SUPERVISOR ONAY — FAZ 4** | Supervisor | ⬜ | 4 | T-043 |
| T-044 | G3: Product CRUD API | @coder-light | ⬜ | 5 | T-009 |
| T-045 | G3.2: StockMovement API (IN/OUT/ADJUSTMENT) | @coder-light | ⬜ | 5 | T-044 |
| T-046 | G3: Product UI (liste, hareket modalı) | @coder-light | ⬜ | 5 | T-044 |
| T-047 | G3.3: Stok sayımı | @coder-heavy | ⬜ | 5 | T-044 |
| T-048 | G3.4: Minimum stok uyarı sistemi | @coder-light | ⬜ | 5 | T-044 |
| T-049 | G5.1: Dashboard kartları (6 kart) | @coder-light | ⬜ | 6 | T-028,T-044 |
| T-050 | G5.2: Dashboard grafikleri (Recharts — 5 grafik) | @coder-heavy | ⬜ | 6 | T-049 |
| T-051 | G5.3: Rapor API'leri (6 rapor) | @coder-heavy | ⬜ | 6 | T-028 |
| T-052 | G5.3: Rapor UI + Excel/PDF export | @coder-heavy | ⬜ | 6 | T-051 |
| T-053 | G6: Customer CRUD API + UI | @coder-light | ⬜ | 7 | T-009 |
| T-054 | G4.2: Sale CRUD API (otomatik kar hesaplama) | @coder-heavy | ⬜ | 7 | T-028,T-053 |
| T-055 | Sale UI (yeni satış, liste, detay) | @coder-heavy | ⬜ | 7 | T-054 |
| T-056 | G4.4: Finansal özet sayfası | @coder-heavy | ⬜ | 7 | T-054 |
| T-057 | Socket.io backend setup + event handler | @coder-heavy | ⬜ | 8 | T-023 |
| T-058 | Frontend useSocket hook + bildirim toast | @coder-heavy | ⬜ | 8 | T-057 |
| T-059 | Vergi/döviz değişikliğinde real-time push | @coder-heavy | ⬜ | 8 | T-057 |
| T-060 | Responsive düzenlemeler + polish | @coder-light | ⬜ | 8 | T-058 |
| T-061 | Full test suite | @tester | ⬜ | 8 | T-059 |
| — | **SUPERVISOR TEST ONAY — FAZ 8** | Supervisor | ⬜ | 8 | T-061 |
| T-062 | Dockerfile'lar (web + api) | @coder-light | ⬜ | 9 | — |
| T-063 | docker-compose.prod.yml | @coder-light | ⬜ | 9 | T-062 |
| T-064 | GitHub Actions CI/CD | @coder-heavy | ⬜ | 9 | T-062 |
| T-065 | Final code review | @reviewer | ⬜ | 9 | T-064 |
| T-066 | Tüm dokümantasyon (README, API docs) | @docs | ⬜ | 9 | T-065 |
| — | **SUPERVISOR FİNAL ONAY** | Supervisor | ⬜ | 9 | T-066 |

**Durum:** ⬜ Başlamadı | 🔄 Devam | ✅ Tamam | ❌ Hata | ⏸️ Bekleme

---

## Hata Kurtarma

| Senaryo | Çözüm |
|---------|-------|
| Session koptu | `claude` → `/resume` |
| Bağlam doldu | Checkpoint yaz → yeni session → `/resume` |
| Prisma migration hatası | `npx prisma migrate reset` → tekrar migrate |
| Sub-agent hata | Retry / farklı agent / Lead müdahale |
| Yanlış yön (Supervisor RED) | Son güvenli checkpoint'e git revert |
| Vergi hesaplama yanlış | `/impact calculator.service.ts` → test'le doğrula |

---

## Checkpoint Kayıtları

### CHECKPOINT-0 — [TARİH]
- **Durum:** ⬜ Başlatılmadı
- **Tamamlanan:** Orkestrasyon sistemi hazırlandı
- **Sıradaki:** Lead Agent başlat → Faz 1 → T-001 monorepo setup
- **Sorunlar:** —
- **Aktif Dosyalar:** ORCHESTRATION.md, CLAUDE.md, SPEC.md
- **Bağımlılıklar:** —
- **Son Komut:** —

---
<!-- YENİ CHECKPOINT'LER BURAYA EKLENİR -->
