description: Supervisor denetimi başlat

ORCHESTRATION.md ve PROJECT_TREE.md oku ve şu kontrolleri yap:

1. **Bütünlük:** Checkpoint'ler arasında atlama var mı?
2. **Tutarlılık:** Görev tablosu ↔ checkpoint'ler uyumlu mu?
3. **Model Kullanımı:** Doğru agent doğru model ile mi çalışıyor?
4. **Kalite:** src/ kodunu incele — mimari uyumu
5. **Proje Ağacı:** PROJECT_TREE.md güncel mi? Uyarılar var mı? (circular dep, orphan, fat file)
6. **Risk:** Bottleneck veya potansiyel sorun var mı?
7. **İlerleme:** Plan dahilinde mi?

Karar:
- ✅ ONAY — Devam
- ⚠️ UYARI — Düzeltme gerekli (detay ver)
- ❌ RED — Dur, yeniden planla (neden)

Geri bildirimi Günlük bölümüne yaz.
