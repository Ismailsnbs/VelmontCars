# 🌳 Project Tree & Dependency Map

> **Son Güncelleme:** `___`
> **Toplam Dosya:** 0
> **Uyarı:** 0

---

## Dosya Yapısı

```
[Proje başlatıldığında @tree-mapper tarafından doldurulur]
```

---

## Bağımlılık Haritası

### Yukarıdan Aşağı (Çağrı Zinciri)
```
[Hangi dosya hangi dosyayı çağırıyor — import akışı]
```

### Aşağıdan Yukarı (Etkilenen Dosyalar)
```
[Bir dosya değişirse hangi dosyalar etkilenir]
```

---

## Etki Analizi

| Dosya Değişirse | Etkilenen Dosyalar | Etki Sayısı | Risk |
|-----------------|-------------------|-------------|------|
| — | — | — | — |

**Risk Seviyeleri:**
- 🔴 Yüksek (5+ bağımlı) → değişiklik öncesi kapsamlı test gerekir
- 🟡 Orta (2-4 bağımlı) → ilgili testleri çalıştır
- 🟢 Düşük (0-1 bağımlı) → güvenle değiştirilebilir

---

## Servis & Flow Haritaları

### Auth Flow
```
[Login/Register/Session akışı]
```

### Data Flow
```
[DB → API → Hook → Component → UI]
```

### API Endpoints
| Method | Path | Handler | Bağımlılıklar |
|--------|------|---------|---------------|
| — | — | — | — |

---

## Uyarılar

| Tip | Dosya | Açıklama |
|-----|-------|----------|
| — | — | — |

**Uyarı Tipleri:**
- 🔴 `CIRCULAR` — Döngüsel bağımlılık (A→B→A)
- 🟡 `ORPHAN` — Hiçbir yerden import edilmeyen dosya
- 🟡 `FAT_FILE` — 200+ satır, bölünmesi önerilir
- 🟡 `HIGH_COUPLING` — 5+ dosyaya bağımlı, refactoring önerilir
- 🔵 `DEEP_CHAIN` — 4+ seviye bağımlılık zinciri

---

## Değişiklik Geçmişi

| Checkpoint | Değişiklik | Etkilenen |
|------------|-----------|-----------|
| — | — | — |

<!-- 
  @tree-mapper bu dosyayı otomatik günceller.
  Manuel düzenleme yapmayın.
  /tree komutu veya /checkpoint sonrası otomatik tetiklenir.
-->
